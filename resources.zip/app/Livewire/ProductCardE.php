<?php

namespace App\Livewire;

use Livewire\Component;

class ProductCardE extends Component
{
    public function render()
    {
        return view('livewire.product-card-e');
    }
}
