@extends('layouts.app')

@section('content')
    <livewire:product-list />
@endsection
